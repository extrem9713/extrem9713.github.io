describe('basicAuth', function () {
  setupBasicAuthTest();
});
